Subject: Want your own AI sidekick in two weeks?

Hey ____,

I’m running a tiny “Build Your Own AI Sidekick (2-week program)” for friends/family. In two weeks we’ll set up a real AI assistant on your laptop—local models, safe automation, no hype.

**What you get**
- Local OpenClaw stack with Ollama
- One workflow automated end-to-end (your choice: morning brief, inbox triage, research assistant, etc.)
- Training so you can keep expanding it after the sprint

**Time commitment:** about 4–5 hours total across group calls + a 1:1 build session.

**Cost:** Friends/family pilot — pay whatever feels fair (or barter coffee/food/etc.).

If you’re in, reply and I’ll send the onboarding doc + schedule. First cohort kicks off on ______.

Let’s build your sidekick before AI does it for you.

—Mark
