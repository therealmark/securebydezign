# Build Your Own AI Sidekick (2-week program) — Onboarding Guide

Use this during the kickoff call with each participant.

## 1. Intake Questions
- Laptop model + macOS version
- Daily workflows that eat time
- Comfort level with Terminal (1–5)
- Must-have integrations (email, calendar, docs, social, etc.)
- Risk tolerance (are they okay connecting work accounts?)

Record answers in a shared doc per participant.

## 2. Schedule
| Day | Session | Notes |
|-----|---------|-------|
| 0   | Invite sent | Include prerequisites + expectations |
| 1   | Group kickoff (60 min) | Walk through kit, set goals |
| 2-3 | Install + hardening (1:1, 90 min each) | Follow README |
| 4   | Workflow workshop (group) | Build from sample scripts |
| 5-6 | 1:1 build day (60 min) | Ship their chosen automation |
| 7   | Demo day (group) | Everyone shows their sidekick |

## 3. Participant Checklist
- [ ] Cloned `sidekick-kit` repo locally
- [ ] Homebrew + Node + Python installed
- [ ] OpenClaw + Ollama running
- [ ] `.env.local` populated
- [ ] Cron/heartbeat configured for at least one workflow
- [ ] Backup script tested

## 4. Support Channel
Create a group chat (Signal/Telegram) named “Build Your Own AI Sidekick (2-week program) 01” for async help.

## 5. Graduation Criteria
- Working automation demoed live
- Safety checklist completed
- Participant can explain how to run/stop/update their assistant
