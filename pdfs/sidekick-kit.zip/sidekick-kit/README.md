# Build Your Own AI Sidekick (2-week program) Starter Kit

This kit is what we’ll hand to friends & family who join the two‑week "Build Your Own AI Sidekick (2-week program)." It contains the scaffolding they need to stand up a local OpenClaw instance, wire in the first workflows, and keep everything safe.

## Contents

```
sidekick-kit/
├── README.md                <-- this doc
└── sidekick/
    ├── config/
    │   ├── openclaw.example.json
    │   └── .env.example
    ├── models/
    │   └── README.md
    ├── scripts/
    │   ├── morning_digest.py
    │   ├── research_digest.py
    │   └── task_router.py
    └── security/
        └── checklist.md
```

## Sprint Overview

1. **Kickoff:** capture the participant’s workflows + environment in a shared doc.
2. **Install + Hardening:** follow the instructions below to get OpenClaw + Ollama running locally.
3. **Workflow Workshop:** use the sample scripts (or clones) to wire the first automation.
4. **1:1 Build Day:** pair up to customize, test, and schedule the automation.
5. **Graduation:** everyone demos their working sidekick.

## Prerequisites

- macOS 13+ (Apple Silicon preferred)
- Homebrew installed
- 30 GB free disk space
- Comfortable with Terminal basics
- A personal e-mail/calendar account they’re willing to connect locally

## Quick Start

```bash
# 1. Install required packages
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install node git python@3.11

# 2. Install OpenClaw + Ollama
npm install -g openclaw
brew install ollama
ollama pull qwen2.5:14b-instruct-q4_0

# 3. Copy config templates
cp sidekick/config/openclaw.example.json ~/.openclaw/openclaw.json
cp sidekick/config/.env.example ~/.openclaw/workspace/.env.local

# 4. Launch OpenClaw once to finish setup
openclaw gateway start
```

During the sprint we’ll customize the config, set up secrets, and plug the scripts into cron or heartbeats.

## Safety Defaults

- We run the primary assistant on the participant’s machine so their data never leaves.
- Local model (Ollama Qwen) is the default. Cloud fallbacks are opt-in.
- Daily encrypted backups run via the stock `memory/bin/backup.sh` script.

## Next Steps

1. Fill in `.env.local` with their API keys (if any) + secrets.
2. Edit `openclaw.json` to point at the scripts they’ll run.
3. Customize one of the sample workflows and schedule it.
4. Use `security/checklist.md` as the review sheet before graduation.

We’ll keep expanding this kit as the sprint evolves.
