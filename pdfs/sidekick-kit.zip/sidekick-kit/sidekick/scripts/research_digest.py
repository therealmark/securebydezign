#!/usr/bin/env python3
"""Sample research digest pipeline.

Outline:
- Accept a list of queries or RSS feeds.
- Use Brave Search API (or another source) to pull top headlines.
- Ask the local model for a concise summary + action items.
- Save to memory and/or send via Telegram.
"""
from pathlib import Path
import json
import datetime as dt

RESULTS_DIR = Path("memory/research-digests")
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

QUERIES = [
    "agentic ai security",
    "zero trust for llm",
    "data poisoning attacks",
]


def fetch_headlines(query: str) -> list:
    # TODO: plug in Brave API or another news source.
    return [f"Placeholder headline for '{query}'"]


def summarize(headlines: list) -> str:
    # TODO: call the local model via OpenClaw’s messaging interface.
    joined = "\n".join(f" - {h}" for h in headlines)
    return f"Key takeaways:\n{joined}\n\n(Replace with LLM summary)"


def run():
    today = dt.date.today().isoformat()
    digest = {"date": today, "entries": []}

    for query in QUERIES:
        headlines = fetch_headlines(query)
        digest["entries"].append({
            "query": query,
            "headlines": headlines,
            "summary": summarize(headlines)
        })

    out_file = RESULTS_DIR / f"research-{today}.json"
    out_file.write_text(json.dumps(digest, indent=2))
    print(f"Saved research digest to {out_file}")


if __name__ == "__main__":
    run()
