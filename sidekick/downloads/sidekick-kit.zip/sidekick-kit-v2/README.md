# Build Your Own AI Sidekick — Starter Kit

The scaffolding for your two-week coaching sprint. Participants use this to stand up a local OpenClaw instance, wire in their first automations, and keep everything safe.

## What's Inside

```
sidekick-kit/
├── README.md              ← you are here
├── ONBOARDING.md          ← coach's guide (intake questions, schedule, graduation)
├── INVITE_TEMPLATE.md     ← message to send friends/family
└── sidekick/
    ├── config/
    │   ├── openclaw.example.json  ← copy to ~/.openclaw/openclaw.json
    │   └── .env.example           ← copy to ~/.openclaw/workspace/.env.local
    ├── workspace/
    │   ├── SOUL.md        ← sidekick personality template
    │   ├── AGENTS.md      ← operating instructions template
    │   └── HEARTBEAT.md   ← periodic task checklist template
    ├── scripts/
    │   ├── test_install.sh        ← Day 0 verification (run this first)
    │   ├── morning_digest.py      ← calendar summary → file/Telegram
    │   ├── research_digest.py     ← Brave Search headlines → digest
    │   ├── task_router.py         ← dispatcher for multiple workflows
    │   └── backup.sh              ← daily encrypted backup
    └── security/
        └── checklist.md           ← graduation sign-off sheet
```

## Quick Start (Day 1)

```bash
# 1. Install prerequisites
brew install node git python@3.11 ollama
npm install -g openclaw

# 2. Pull local model (7b = ~4.4GB, fast; 14b = ~8.5GB, smarter)
ollama pull qwen2.5:7b-instruct-q4_0

# 3. Copy config templates
mkdir -p ~/.openclaw/workspace
cp sidekick/config/openclaw.example.json ~/.openclaw/openclaw.json
cp sidekick/config/.env.example ~/.openclaw/workspace/.env.local
cp sidekick/workspace/SOUL.md ~/.openclaw/workspace/SOUL.md
cp sidekick/workspace/AGENTS.md ~/.openclaw/workspace/AGENTS.md
cp sidekick/workspace/HEARTBEAT.md ~/.openclaw/workspace/HEARTBEAT.md

# 4. Edit your persona and secrets
open ~/.openclaw/workspace/SOUL.md       # make it yours
open ~/.openclaw/workspace/.env.local    # add API keys if using cloud fallbacks

# 5. Start OpenClaw
openclaw gateway install
openclaw gateway status

# 6. Verify everything works
bash sidekick/scripts/test_install.sh

# 7. Set up backups
bash sidekick/scripts/backup.sh --setup
```

## Sprint Overview

| Day | Activity | Time |
|-----|----------|------|
| 0 | Invite sent | — |
| 1 | Group kickoff — walk through kit, set goals | 60 min |
| 2–3 | 1:1 install + hardening session | 90 min each |
| 4 | Group workflow workshop — build from sample scripts | 60 min |
| 5–6 | 1:1 build day — ship their chosen automation | 60 min |
| 7 | Demo day — everyone shows their sidekick | 45 min |

## Model Choice

| Model | Size | Best for |
|-------|------|----------|
| `qwen2.5:7b-instruct-q4_0` | 4.4 GB | **Start here.** Fast, handles most tasks |
| `qwen2.5:14b-instruct-q4_0` | 8.5 GB | Better writing/reasoning, needs ~10GB RAM |

Cloud fallbacks (Anthropic, OpenAI) are configured in `openclaw.example.json` but disabled by default. Enable them by adding API keys to `.env.local`.

## Safety Defaults

- Primary model runs 100% on-device — no data leaves the machine
- Cloud fallbacks are opt-in per workflow
- Encrypted backups run daily via `backup.sh`
- Security checklist required before graduation

## Troubleshooting

Run the test script — it diagnoses most common issues:
```bash
bash sidekick/scripts/test_install.sh
```

Common fixes:
- **Gateway not running:** `openclaw gateway install && openclaw gateway status`
- **Ollama not running:** `ollama serve` (or it auto-starts on first use)
- **Model not found:** `ollama pull qwen2.5:7b-instruct-q4_0`
