# Invite Template

_Fill in [YOUR NAME], [COHORT START DATE], and [YOUR CONTACT] before sending._

---

**Subject:** Want your own AI sidekick in two weeks?

Hey [FIRST NAME],

I'm running a small "Build Your Own AI Sidekick" program for friends and family. In two weeks we'll set up a real AI assistant on your laptop — local models, safe automation, no subscription fees, no hype.

**What you get:**
- A personal AI running entirely on your machine (your data stays yours)
- One workflow automated end-to-end — your choice: morning briefing, inbox triage, research assistant, reminder system, etc.
- Hands-on coaching so you can keep expanding it after we're done

**Time commitment:** ~4–5 hours total across two group sessions and one 1:1 build session.

**Cost:** Friends and family pilot — pay what feels fair. Seriously.

**What you need:** A Mac (Apple Silicon preferred), Terminal basics, and curiosity. I'll handle the rest.

If you're in, just reply and I'll send you the onboarding doc and the schedule. First cohort kicks off [COHORT START DATE].

[YOUR NAME]
[YOUR CONTACT]

---

_Tip: Personalize the "workflow" line based on what you know about this person — it dramatically improves conversion._
