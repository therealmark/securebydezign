# HEARTBEAT.md
# Keep empty to do nothing on heartbeat polls.
# Add tasks below to have your sidekick check things automatically.

# Examples (uncomment and customize):

# - Check for new emails and summarize anything urgent
# - Check calendar for events in the next 2 hours
# - Run morning_digest.py if it's between 7-9am and hasn't run today
# - Remind me about active tasks if it's been more than 4 hours
