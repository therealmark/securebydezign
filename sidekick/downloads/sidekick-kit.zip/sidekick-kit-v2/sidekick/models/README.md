# Model Loadout

Default choice for the sprint is **Ollama `qwen2.5:14b-instruct-q4_0`** because:
- Runs entirely on Apple Silicon laptops
- Handles planning + writing well enough for personal workflows
- No API cost, so participants can experiment freely

## Installation
```bash
brew install ollama
ollama pull qwen2.5:14b-instruct-q4_0
```

## Optional Cloud Fallbacks
Only enable if the participant needs higher quality for a specific task.
- `openai/gpt-4o-mini` – strong reasoning, lowish cost
- `anthropic/claude-3-haiku` – fast summarizer

Configure fallbacks inside `openclaw.json` and make sure API keys live in `.env.local`.

## Safety Tips
- Keep cloud keys disabled by default; toggle per-workflow if necessary.
- Log which model handled each automation so troubleshooting is easy.
