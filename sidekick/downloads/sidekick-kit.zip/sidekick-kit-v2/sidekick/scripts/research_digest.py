#!/usr/bin/env python3
"""Research digest — pulls top headlines for your topics via Brave Search API.

Run directly:
    python scripts/research_digest.py

Setup:
    1. Get a free Brave Search API key: https://api.search.brave.com
    2. Set BRAVE_API_KEY in .env.local
    3. Edit QUERIES below to match your interests

Output saved to memory/research-digests/YYYY-MM-DD.json
"""
import os
import sys
import json
import datetime as dt
import urllib.request
import urllib.parse
from pathlib import Path

# ── Load .env.local ────────────────────────────────────────────────────────
env_file = Path(__file__).parent.parent.parent / ".env.local"
if env_file.exists():
    for line in env_file.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip())

RESULTS_DIR = Path("memory/research-digests")
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

# ── Edit these to match your interests ────────────────────────────────────
QUERIES = [
    "agentic AI news",
    "local LLM tools",
    "AI productivity workflows",
]


# ── Brave Search ───────────────────────────────────────────────────────────
def fetch_headlines(query: str, count: int = 5) -> list[dict]:
    api_key = os.environ.get("BRAVE_API_KEY")
    if not api_key:
        return [{"title": f"(no results — set BRAVE_API_KEY in .env.local)", "url": ""}]

    url = f"https://api.search.brave.com/res/v1/news/search?{urllib.parse.urlencode({'q': query, 'count': count, 'freshness': 'pd'})}"
    req = urllib.request.Request(url, headers={
        "Accept": "application/json",
        "Accept-Encoding": "gzip",
        "X-Subscription-Token": api_key,
    })
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
            return [
                {"title": r.get("title", ""), "url": r.get("url", ""), "desc": r.get("description", "")}
                for r in data.get("results", [])
            ]
    except Exception as e:
        return [{"title": f"(fetch error: {e})", "url": ""}]


# ── Main ───────────────────────────────────────────────────────────────────
def run():
    today = dt.date.today().isoformat()
    digest = {"date": today, "entries": []}

    for query in QUERIES:
        print(f"Searching: {query}...")
        results = fetch_headlines(query)
        digest["entries"].append({"query": query, "results": results})
        for r in results:
            print(f"  • {r['title']}")

    out_file = RESULTS_DIR / f"research-{today}.json"
    out_file.write_text(json.dumps(digest, indent=2))
    print(f"\n✓ Saved to {out_file}")


if __name__ == "__main__":
    run()
