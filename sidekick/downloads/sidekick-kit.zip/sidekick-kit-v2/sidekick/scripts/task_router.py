#!/usr/bin/env python3
"""Minimal task router for the sidekick.

OpenClaw can point the agent entry to this file. It inspects the inbound
message/task name and dispatches to the right workflow.
"""
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
SCRIPTS = {
    "morning-digest": BASE / "morning_digest.py",
    "research-digest": BASE / "research_digest.py",
}


def run(task: str):
    script = SCRIPTS.get(task)
    if not script:
        raise SystemExit(f"Unknown task '{task}'. Known: {list(SCRIPTS)}")
    exec(script.read_text(), {})


if __name__ == "__main__":
    task = sys.argv[1] if len(sys.argv) > 1 else "morning-digest"
    run(task)
