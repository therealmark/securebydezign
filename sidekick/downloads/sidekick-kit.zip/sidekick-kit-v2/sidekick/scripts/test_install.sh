#!/usr/bin/env bash
# =============================================================================
# test_install.sh — Day 0 verification. Run this after setup to confirm
# everything is working before your first coaching session.
#
# Usage: bash sidekick/scripts/test_install.sh
# =============================================================================

PASS=0; FAIL=0
ok()   { echo "  ✅ $1"; PASS=$((PASS+1)); }
fail() { echo "  ❌ $1"; FAIL=$((FAIL+1)); }
info() { echo "  ℹ️  $1"; }
section() { echo ""; echo "── $1 ──────────────────────────────────"; }

echo ""
echo "🔍 Sidekick Install Check"
echo "========================="

section "Core Tools"
command -v brew    &>/dev/null && ok "Homebrew installed"    || fail "Homebrew missing — /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
command -v node    &>/dev/null && ok "Node.js installed"     || fail "Node.js missing — brew install node"
command -v python3 &>/dev/null && ok "Python 3 installed"    || fail "Python 3 missing — brew install python@3.11"
command -v git     &>/dev/null && ok "Git installed"         || fail "Git missing — brew install git"
command -v aws     &>/dev/null && ok "AWS CLI installed"     || info "AWS CLI not installed (optional) — brew install awscli"

section "OpenClaw"
if command -v openclaw &>/dev/null; then
  ok "OpenClaw installed ($(openclaw --version 2>/dev/null | head -1))"
  if openclaw gateway status 2>/dev/null | grep -q "ok\|running\|loaded"; then
    ok "Gateway running"
  else
    fail "Gateway not running — run: openclaw gateway install"
  fi
else
  fail "OpenClaw missing — npm install -g openclaw"
fi

section "Ollama + Models"
if command -v ollama &>/dev/null; then
  ok "Ollama installed ($(ollama --version 2>/dev/null))"
  if curl -s http://localhost:11434/api/tags &>/dev/null; then
    ok "Ollama server running"
    MODELS=$(ollama list 2>/dev/null)
    echo "$MODELS" | grep -q "qwen2.5:7b"  && ok "qwen2.5:7b model available"  || info "qwen2.5:7b not pulled — run: ollama pull qwen2.5:7b-instruct-q4_0"
    echo "$MODELS" | grep -q "qwen2.5:14b" && ok "qwen2.5:14b model available" || info "qwen2.5:14b not pulled (optional) — ollama pull qwen2.5:14b-instruct-q4_0"
  else
    fail "Ollama server not running — run: ollama serve"
  fi
else
  fail "Ollama missing — brew install ollama"
fi

section "Config Files"
[[ -f ~/.openclaw/openclaw.json ]]     && ok "openclaw.json exists"  || fail "openclaw.json missing — cp sidekick/config/openclaw.example.json ~/.openclaw/openclaw.json"
[[ -f ~/.openclaw/workspace/SOUL.md ]] && ok "SOUL.md exists"       || fail "SOUL.md missing — cp sidekick/workspace/SOUL.md ~/.openclaw/workspace/SOUL.md"
[[ -f ~/.openclaw/workspace/AGENTS.md ]] && ok "AGENTS.md exists"   || fail "AGENTS.md missing"

ENV_FILE=~/.openclaw/workspace/.env.local
if [[ -f "$ENV_FILE" ]]; then
  ok ".env.local exists"
  grep -q "^BRAVE_API_KEY=.\+" "$ENV_FILE" && ok "Brave API key set"       || info "Brave API key not set (optional, for research_digest)"
  grep -q "^TELEGRAM_BOT_TOKEN=.\+" "$ENV_FILE" && ok "Telegram token set" || info "Telegram not configured (optional)"
else
  fail ".env.local missing — cp sidekick/config/.env.example ~/.openclaw/workspace/.env.local"
fi

section "Scripts"
cd ~/.openclaw/workspace 2>/dev/null || true
if python3 ~/sidekick-kit/sidekick/scripts/morning_digest.py &>/dev/null; then
  ok "morning_digest.py runs without errors"
else
  fail "morning_digest.py failed — check Python 3 install"
fi

section "Backup"
[[ -f ~/sidekick-kit/sidekick/scripts/backup.sh ]] && ok "backup.sh present" || fail "backup.sh missing"
if security find-generic-password -s "sidekick-backup-key" -a "$USER" -w &>/dev/null || [[ -f ~/.sidekick-backup-key ]]; then
  ok "Backup key found"
else
  info "No backup key yet — run: bash sidekick/scripts/backup.sh --setup"
fi

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════"
echo "  Passed: $PASS   Failed: $FAIL"
echo "═══════════════════════════════════"
if [[ $FAIL -eq 0 ]]; then
  echo "  🎉 All checks passed — you're ready!"
else
  echo "  ⚠️  Fix the items above, then re-run this script."
fi
echo ""
