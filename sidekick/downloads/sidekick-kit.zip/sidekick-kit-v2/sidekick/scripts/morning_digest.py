#!/usr/bin/env python3
"""Morning digest workflow.

Reads your local calendar (.ics), summarizes today's events,
and saves a digest to memory/morning-digests/YYYY-MM-DD.md

Run directly:
    python scripts/morning_digest.py

Or wire into OpenClaw heartbeat / cron for daily delivery.

Setup:
    1. Export your calendar: macOS Calendar → File → Export → Calendar.ics
    2. Set CALENDAR_ICS_PATH in .env.local (or pass as env var)
    3. Optionally set TELEGRAM_BOT_TOKEN + TELEGRAM_CHAT_ID to receive via Telegram
"""
import datetime as dt
import os
import sys
import json
from pathlib import Path

# ── Load .env.local if present ─────────────────────────────────────────────
env_file = Path(__file__).parent.parent.parent / ".env.local"
if env_file.exists():
    for line in env_file.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip())

OUTPUT_DIR = Path("memory/morning-digests")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

today = dt.date.today()
now = dt.datetime.now()


# ── Calendar ───────────────────────────────────────────────────────────────
def fetch_calendar_events() -> list[dict]:
    ics_path = Path(os.environ.get("CALENDAR_ICS_PATH", "")).expanduser()
    if not ics_path.exists():
        return [{"time": "—", "title": "(no calendar connected — set CALENDAR_ICS_PATH in .env.local)"}]

    try:
        # Basic ICS parser — no external deps required
        events = []
        text = ics_path.read_text(errors="replace")
        for vevent in text.split("BEGIN:VEVENT")[1:]:
            title = ""
            start = ""
            for line in vevent.splitlines():
                if line.startswith("SUMMARY:"):
                    title = line[8:].strip()
                if line.startswith("DTSTART"):
                    raw = line.split(":")[-1].strip()
                    try:
                        if "T" in raw:
                            d = dt.datetime.strptime(raw[:15], "%Y%m%dT%H%M%S")
                            if d.date() == today:
                                start = d.strftime("%I:%M %p")
                        else:
                            d = dt.datetime.strptime(raw[:8], "%Y%m%d").date()
                            if d == today:
                                start = "All day"
                    except ValueError:
                        pass
            if start and title:
                events.append({"time": start, "title": title})
        return events if events else [{"time": "—", "title": "No events today"}]
    except Exception as e:
        return [{"time": "—", "title": f"(calendar parse error: {e})"}]


# ── Build digest ───────────────────────────────────────────────────────────
def build_digest() -> str:
    events = fetch_calendar_events()

    lines = [
        f"# Morning Digest — {today.strftime('%A, %B %d %Y')}",
        f"_Generated {now.strftime('%I:%M %p')}_",
        "",
        "## 📅 Today's Calendar",
    ]

    if events:
        for e in events:
            lines.append(f"- **{e['time']}** — {e['title']}")
    else:
        lines.append("- No events found")

    lines += [
        "",
        "## 📬 Inbox",
        "- _(connect email: set EMAIL_SMTP_HOST in .env.local)_",
        "",
        "## 🎯 Game Plan",
        "- _(wire this to your local model for a generated plan)_",
        "",
        "---",
        "_Edit `scripts/morning_digest.py` to hook up email + LLM summarization._",
    ]

    return "\n".join(lines)


# ── Send via Telegram (optional) ───────────────────────────────────────────
def send_telegram(text: str):
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    chat_id = os.environ.get("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        return

    import urllib.request
    payload = json.dumps({"chat_id": chat_id, "text": text, "parse_mode": "Markdown"}).encode()
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{token}/sendMessage",
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    try:
        urllib.request.urlopen(req, timeout=10)
        print("Digest sent via Telegram ✓")
    except Exception as e:
        print(f"Telegram send failed: {e}", file=sys.stderr)


# ── Main ───────────────────────────────────────────────────────────────────
def run():
    digest = build_digest()

    out_file = OUTPUT_DIR / f"digest-{today}.md"
    out_file.write_text(digest)
    print(f"✓ Saved digest to {out_file}")
    print()
    print(digest)

    send_telegram(digest)


if __name__ == "__main__":
    run()
