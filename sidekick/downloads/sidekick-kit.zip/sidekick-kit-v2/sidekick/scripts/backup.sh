#!/usr/bin/env bash
# =============================================================================
# backup.sh — Daily encrypted backup of your sidekick config + workspace
#
# Usage:
#   bash scripts/backup.sh                  # run backup
#   bash scripts/backup.sh --setup          # first-time setup (generate key)
#
# What it backs up:
#   - openclaw.json (config)
#   - .env.local (your secrets — encrypted)
#   - workspace/ (SOUL.md, AGENTS.md, memory files)
#
# Where: local archive at ~/.sidekick-backups/ (rotate last 30)
# Optional S3: set BACKUP_S3_BUCKET in .env.local
# =============================================================================
set -euo pipefail

OPENCLAW_DIR="$HOME/.openclaw"
BACKUP_DIR="$HOME/.sidekick-backups"
WORKSPACE="$OPENCLAW_DIR/workspace"
MAX_BACKUPS=30
TIMESTAMP=$(date +"%Y-%m-%d_%H-%M")

# ── Load .env.local ──────────────────────────────────────────────────────────
ENV_FILE="$WORKSPACE/.env.local"
if [[ -f "$ENV_FILE" ]]; then
  while IFS= read -r line; do
    [[ "$line" =~ ^[A-Z_]+=.* ]] && export "$line" 2>/dev/null || true
  done < "$ENV_FILE"
fi

log() { echo "[$(date '+%H:%M:%S')] $*"; }

# ── First-time setup ─────────────────────────────────────────────────────────
if [[ "${1:-}" == "--setup" ]]; then
  KEY=$(openssl rand -hex 32)
  security add-generic-password -s "sidekick-backup-key" -a "$USER" \
    -T /usr/bin/security -w "$KEY" 2>/dev/null || \
  security add-generic-password -s "sidekick-backup-key" -a "$USER" -w "$KEY"
  echo "$KEY" > "$HOME/.sidekick-backup-key" && chmod 600 "$HOME/.sidekick-backup-key"
  log "✓ Backup key generated and stored in Keychain + $HOME/.sidekick-backup-key"
  log "  Save this key somewhere safe outside this machine:"
  echo ""
  echo "  $KEY"
  echo ""
  exit 0
fi

# ── Get key ──────────────────────────────────────────────────────────────────
BACKUP_KEY=$(security find-generic-password -s "sidekick-backup-key" -a "$USER" -w 2>/dev/null) || \
BACKUP_KEY=$(cat "$HOME/.sidekick-backup-key" 2>/dev/null) || {
  log "No backup key found. Run: bash scripts/backup.sh --setup"
  exit 1
}

mkdir -p "$BACKUP_DIR"

# ── Encrypt secrets ───────────────────────────────────────────────────────────
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

tar -czf - -C "$HOME" \
  --exclude=".openclaw/workspace/securebydezign.com" \
  --exclude=".openclaw/workspace/.git" \
  --exclude="*.lock" --exclude=".DS_Store" \
  .openclaw/openclaw.json \
  .openclaw/agents/main/agent/ \
  .openclaw/workspace/SOUL.md \
  .openclaw/workspace/AGENTS.md \
  .openclaw/workspace/USER.md \
  .openclaw/workspace/HEARTBEAT.md \
  .openclaw/workspace/memory/ \
  2>/dev/null \
| openssl enc -aes-256-cbc -pbkdf2 -iter 100000 \
  -pass "pass:$BACKUP_KEY" -out "$TMP/backup.tar.gz.enc"

cp "$TMP/backup.tar.gz.enc" "$BACKUP_DIR/sidekick-$TIMESTAMP.tar.gz.enc"
log "✓ Backup saved: $BACKUP_DIR/sidekick-$TIMESTAMP.tar.gz.enc"

# ── Rotate old backups ────────────────────────────────────────────────────────
ls -t "$BACKUP_DIR"/sidekick-*.tar.gz.enc 2>/dev/null | tail -n +$((MAX_BACKUPS + 1)) | xargs rm -f 2>/dev/null || true

# ── Optional S3 upload ────────────────────────────────────────────────────────
if [[ -n "${BACKUP_S3_BUCKET:-}" ]]; then
  aws s3 cp "$BACKUP_DIR/sidekick-$TIMESTAMP.tar.gz.enc" \
    "s3://$BACKUP_S3_BUCKET/sidekick-backups/sidekick-$TIMESTAMP.tar.gz.enc" \
    --sse AES256 && log "✓ Uploaded to s3://$BACKUP_S3_BUCKET"
fi

log "Done."
