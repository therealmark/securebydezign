# Sidekick Security Checklist

Use this before we “graduate” a participant.

## 1. Environment
- [ ] macOS patched, FileVault enabled
- [ ] Dedicated user account (or at least password protected)
- [ ] Homebrew + OpenClaw + Ollama installed from official sources

## 2. Secrets & Config
- [ ] `.env.local` stored outside git, backed up via encrypted tar
- [ ] API keys restricted to least privilege (read-only where possible)
- [ ] Telegram/Slack tokens scoped to a single bot/user
- [ ] Secrets never logged (check OpenClaw logs)

## 3. Data Boundaries
- [ ] Local model used by default; cloud fallbacks only for allowed data
- [ ] Memory directory excluded from cloud sync services unless encrypted
- [ ] Daily backup script configured with passphrase stored in Keychain

## 4. Workflow Safety
- [ ] Each automation reviewed for destructive commands (e.g., file delete, network calls)
- [ ] Human-in-the-loop for any outbound email/chat automation
- [ ] Cron jobs limited to trusted scripts inside `sidekick/scripts`

## 5. Observability
- [ ] Logs rotate (logrotate or OpenClaw built-in)
- [ ] Quick test command documented (`python scripts/morning_digest.py` etc.)
- [ ] Monitoring ping (optional) sends “sidekick alive” message daily

## 6. Recovery
- [ ] Backup restore test performed at least once
- [ ] Documented steps to restart OpenClaw + Ollama after reboot

Sign-off:
- Participant initials: ____________
- Coach initials: ________
- Date: _______________
